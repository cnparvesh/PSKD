import React from 'react';
import { Code, Palette, Globe } from 'lucide-react';

const About = () => {
  const skills = [
    { icon: Code, title: 'Frontend Development', desc: 'React, Vue, Angular' },
    { icon: Globe, title: 'Backend Development', desc: 'Node.js, Python, Java' },
    { icon: Palette, title: 'UI/UX Design', desc: 'Figma, Adobe XD' },
  ];

  return (
    <div className="min-h-screen bg-white py-20 px-4">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12">About Me</h2>
        
        <div className="mb-12">
          <p className="text-gray-600 leading-relaxed">
            I'm a passionate developer with over 5 years of experience in creating beautiful and functional web applications. 
            I specialize in building responsive, user-friendly interfaces and robust backend systems.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {skills.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="p-6 bg-gray-50 rounded-lg hover:shadow-md transition-shadow">
              <Icon className="w-10 h-10 text-purple-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">{title}</h3>
              <p className="text-gray-600">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default About;