import React from 'react';
import { Github, Linkedin, Twitter } from 'lucide-react';

const Home = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 to-blue-50">
      <div className="text-center px-4">
        <img
          src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150"
          alt="Profile"
          className="w-32 h-32 rounded-full mx-auto mb-8 border-4 border-white shadow-lg"
        />
        <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-purple-600 to-blue-500 bg-clip-text text-transparent">
          John Doe
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          Full Stack Developer & UI/UX Designer
        </p>
        <div className="flex justify-center space-x-4 mb-8">
          <SocialLink icon={Github} href="https://github.com" />
          <SocialLink icon={Linkedin} href="https://linkedin.com" />
          <SocialLink icon={Twitter} href="https://twitter.com" />
        </div>
        <button className="bg-purple-600 text-white px-8 py-3 rounded-full hover:bg-purple-700 transition-colors shadow-lg">
          View My Work
        </button>
      </div>
    </div>
  );
};

const SocialLink = ({ icon: Icon, href }: { icon: any; href: string }) => (
  <a
    href={href}
    target="_blank"
    rel="noopener noreferrer"
    className="p-3 bg-white rounded-full shadow-md hover:shadow-lg transition-shadow"
  >
    <Icon className="w-6 h-6 text-gray-700" />
  </a>
);

export default Home;