import React from 'react';
import { Home, User, Mail, MessageSquare, Briefcase } from 'lucide-react';

const Navbar = ({ activeSection, setActiveSection }: { 
  activeSection: string;
  setActiveSection: (section: string) => void;
}) => {
  const navItems = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'about', icon: User, label: 'About' },
    { id: 'projects', icon: Briefcase, label: 'Projects' },
    { id: 'contact', icon: Mail, label: 'Contact' },
    { id: 'message', icon: MessageSquare, label: 'Message' },
  ];

  return (
    <nav className="fixed top-0 w-full bg-white/90 backdrop-blur-sm shadow-sm z-50">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-500 bg-clip-text text-transparent">
            Portfolio
          </span>
          <div className="flex space-x-4">
            {navItems.map(({ id, icon: Icon, label }) => (
              <button
                key={id}
                onClick={() => setActiveSection(id)}
                className={`flex items-center space-x-1 px-3 py-2 rounded-md transition-all
                  ${activeSection === id 
                    ? 'bg-purple-100 text-purple-600' 
                    : 'hover:bg-gray-100'
                  }`}
              >
                <Icon className="w-4 h-4" />
                <span>{label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;